# README and VIDEO

Your _readme_ goes here

Your _video_ must replace the `demo.mp4` file in this folder

Before submitting your coursework, run `./clean.sh` as this will remove the virtual environment which can be reconstructed locally.

