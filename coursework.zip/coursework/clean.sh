# remove the files that can be installed
echo Cleaning up the virtual environment
rm -r __pycache__
rm -r vcwk
rm .env


